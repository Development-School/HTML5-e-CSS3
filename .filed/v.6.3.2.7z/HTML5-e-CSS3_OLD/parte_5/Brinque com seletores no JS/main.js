
// alert('Teste');

// document.querySelector('input[type=tel]');
// document.querySelector('input[type=button]')

// document.querySelector('.telefone');

document.querySelector('input[type=tel]');